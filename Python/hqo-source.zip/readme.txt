HeroQuest Online Plus Game Client
Copyright (C) 2011 Daniel Bekowies


Client server implementation of the famous boardgame HeroQuest using the rules
of HeroQuest Brave Edition (http://www.heroquestworld.de/sites/brave/).

The game is written in Delphi and Assembler and requires Borland Delphi 7 or a
compatible compiler. You also have to install the HQO+ game pack from
http://www.kitana.org/playground/heroquest/heroquest.html to your developement
folder in order to run the application or it will crash due to missing data
files.

The original sources can be downloaded from http://www.kitana.org/heroquest


Date: February 03, 2011
